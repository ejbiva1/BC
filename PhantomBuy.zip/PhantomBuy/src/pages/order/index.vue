<template>
    <div class="animated fadeIn">
    </div>
</template>

<script type="text/ecmascript-6">
    export default {}
</script>

<style scoped>

</style>

