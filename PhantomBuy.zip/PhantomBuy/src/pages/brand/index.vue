<template>
    <div class="animated fadeIn">
    </div>
</template>

<!--品牌-->
<script type="text/ecmascript-6">
    export default {}
</script>

<style scoped>

</style>

