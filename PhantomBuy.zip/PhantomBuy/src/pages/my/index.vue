<template>
  <div class="my">
    <div class="container">
      <div class="header">

        <div class="userImg">
          <open-data class="thumb" type="userAvatarUrl"></open-data>
        </div>
        <div class="userName">
          <open-data class="nackname" lang="zh_CN" type="userNickName"></open-data>
        </div>
      </div>
      <!--<div class="signOut">退出账号</div>-->
    </div>

  </div>
</template>

<script type="text/ecmascript-6">
    export default {}
</script>

<style scoped>

</style>

