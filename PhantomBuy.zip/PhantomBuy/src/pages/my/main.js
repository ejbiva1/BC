/**
 * Created by rdai2 on 2019/2/26.
 */
import Vue from 'vue'
import App from './index'

const app = new Vue(App)
app.$mount()

