/**
 * Created by rdai2 on 2019/2/26.
 */
export const brand_list = [
  {
    id: 1,
    name: 'Abercrombie & Fitch',
    src: './../../static/images/site.jpg'
  },
  {
    id: 2,
    name: 'Tommy Hilfiger',
    src: './../../static/images/site.jpg'
  },
  {
    id: 3,
    name: "Macy's",
    src: './../../static/images/site.jpg'
  },
  {
    id: 4,
    name: 'Ralph Lauren',
    src: './../../static/images/site.jpg'
  },
  {
    id: 5,
    name: '梅西百货美妆',
    src: './../../static/images/site.jpg'
  },
  {
    id: 6,
    name: '梅西百货美包',
    src: './../../static/images/site.jpg'
  },
  {
    id: 7,
    name: 'COACH',
    src: './../../static/images/site.jpg'
  },
  {
    id: 8,
    name: 'Michael Kors',
    src: './../../static/images/site.jpg'
  },
  {
    id: 9,
    name: 'Tory Burch',
    src: './../../static/images/site.jpg'
  },
  {
    id: 10,
    name: 'MCM',
    src: './../../static/images/site.jpg'
  }
];
